<?php

return [
    'searching_for_delivery_man'=>'البحث عن مندوب التوصيل',
    'accepted_by_delivery_man'=>'قبلها رجل التسليم',
    'preparing_in_restaurants'=>'التجهيز فى المحل',
    'picked_up'=>'التقطت',
    'dashboard_order_statistics'=>'احصائيات الطلب لوحة التحكم',
];
